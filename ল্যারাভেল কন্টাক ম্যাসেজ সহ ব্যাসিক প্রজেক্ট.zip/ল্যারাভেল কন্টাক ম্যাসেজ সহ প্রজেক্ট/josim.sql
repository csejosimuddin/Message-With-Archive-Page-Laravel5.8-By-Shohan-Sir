-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2021 at 07:19 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `josim`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_id`, `menu_status`, `created_at`, `updated_at`) VALUES
(1, 'man', 1, '2021-05-29 03:14:52', '2021-06-03 21:55:54'),
(2, 'Woman', 0, '2021-05-29 03:16:28', '2021-06-03 21:55:59'),
(3, 'child', 0, '2021-05-29 03:17:10', '2021-06-03 21:56:11'),
(4, 'App Development', 0, '2021-05-29 10:40:36', NULL),
(5, 'josim', 1, '2021-05-30 18:39:32', '2021-06-03 21:56:26'),
(6, 'Laravel', 0, '2021-05-30 18:46:39', '2021-05-30 13:17:05'),
(7, 'SPC', 1, '2021-06-04 05:11:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `first_name`, `last_name`, `subject`, `message`, `read_status`, `created_at`, `updated_at`) VALUES
(1, 'first', 'secend', 'valo', 'valo', 1, NULL, NULL),
(2, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'SSL/TSL Renew SSL/TSL Renew SSL/TSL Renew', 1, NULL, NULL),
(3, 'MD. AL AMIN', 'Rahaman', '<div class=\"alert alert-success\">', '<div class=\"<div class=\"alert alert-success\">alert alert-success\">', 1, NULL, NULL),
(4, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'SSL/TSL Renew', 1, NULL, NULL),
(5, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'Hello', 1, NULL, NULL),
(6, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'Hello', 1, NULL, NULL),
(7, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'Hello', 1, NULL, NULL),
(8, 'MD. AL AMIN', 'Sattar', 'SSL/TSL Renew', 'Josim', 1, NULL, NULL),
(9, 'SARROWER ZAHAN SOJIB', 'mahi', 'Vai', 'Secend Message', 1, NULL, NULL),
(10, 'MD. RAKIBUL ISLAM', 'Sattar', 'Vai', 'I Am Your Message!!', 1, NULL, NULL),
(11, 'MD. RAKIBUL ISLAM', 'Sattar', 'Vai', 'I Am Your Message!!', 1, NULL, NULL),
(12, 'f', 'f', 'f', 'ffff', 1, NULL, NULL),
(13, 'f', 'f', 'f', 'ffff', 1, NULL, NULL),
(14, 'f', 'f', 'f', 'ffffbb', 1, NULL, NULL),
(15, 'q', 'q', 'q', 'aaa', 1, NULL, NULL),
(16, 'MD. AZAD RAHMAN LIKHON', 'Babu', 'SSL/TSL Renew', 'Ami course korte chai', 2, NULL, '2021-06-03 23:09:44'),
(17, 'SHIMUL PARVEZ', 'Rahaman', 'SSL/TSL Renew', 'xvxnbhjbdf', 2, NULL, NULL),
(18, 'scc', 'scasc', 'ascas', 'asxasc', 2, NULL, '2021-06-03 23:08:40'),
(19, 'xx', 'xx', 'xx', 'xxx', 2, NULL, '2021-06-03 23:09:35'),
(20, 's', 's', 's', 's', 2, NULL, '2021-06-03 23:09:41'),
(21, 'মো:জসিম উদ্দীন', 'সরকার', 'ওয়েব ডিজাইন', 'আমি এই কোর্সটি করতে আগ্রহী ০১৭২২৮৫৮৬৭৭', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2021_05_29_030841_categories', 3),
(7, '2021_05_29_041450_product', 4),
(8, '2021_06_03_102643_contact', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_p_id` int(11) NOT NULL,
  `Product_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Product_Description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Product_Price` int(11) NOT NULL,
  `Product_Quentity` int(11) NOT NULL,
  `Product_Alert_Quentity` int(11) NOT NULL,
  `Product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'defaultproductphoto.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_p_id`, `Product_Name`, `Product_Description`, `Product_Price`, `Product_Quentity`, `Product_Alert_Quentity`, `Product_image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'cit', 'scc', 1550, 100, 1, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(2, 1, 'cit', 'bh', 15, 21, 1, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(3, 3, 'child', 'chilaa', 120, 14, 1, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(4, 4, 'App Development', 'App Development App DevelopmentApp Development App DevelopmentApp Development', 2, 14, 5, '4.jpg', NULL, '2021-05-29 04:41:17', NULL),
(5, 3, 'child', 'childchildchild', 100, 25478, 5, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(6, 6, 'ল্যারাভেল', 'ল্যারাভেলল্যারাভেলল্যারাভেলল্যারাভেল', 15, 21, 15, 'defaultproductphoto.jpg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Md. Abdur Rahman', 'aurocafe4@gmail.com', NULL, '$2y$10$4nFP3cJHPsufN9j3NYvDf.LP4p0YhNw7P9j2r3yubvUjcYVR76Ie6', '0ZBT8zcmesqVA3LvwtNC0Um6UWiTmKAgcTGlQrJwH7hxAUzxzodNaCmhhTWz', '2021-05-09 10:59:54', '2021-05-09 10:59:54'),
(2, 'admin', 'admin@gmail.com', NULL, '$2y$10$y7iLmkx8hYE0pCxVFYMgE.XsB8XApUJx2sdq6z56K5PKdsHfblJ9u', 'EfmguntGAKIZAJz8cAOjmIMKoRuHxi562eW3EABaZdSFl5Qszl4IKYIMND35', '2021-05-17 21:06:07', '2021-05-17 21:06:07'),
(3, 'about', 'aboutecare@gmail.com', NULL, '$2y$10$/0rblDOo7i719M0DmjN.3OTuE1/LrlEpRdoG0AQPvWryJCF6N74Vi', 'cfmHFuz70DeNnLpRSbYhTRPqxiAbvfeFks4qCMGIW2r1A5R5LoquLUQBEF2v', '2021-05-30 22:25:00', '2021-05-30 22:30:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
