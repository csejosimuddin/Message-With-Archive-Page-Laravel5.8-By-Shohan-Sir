<?php echo e($slot); ?>

<?php /**PATH C:\Users\Josim\Desktop\josim\blog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>