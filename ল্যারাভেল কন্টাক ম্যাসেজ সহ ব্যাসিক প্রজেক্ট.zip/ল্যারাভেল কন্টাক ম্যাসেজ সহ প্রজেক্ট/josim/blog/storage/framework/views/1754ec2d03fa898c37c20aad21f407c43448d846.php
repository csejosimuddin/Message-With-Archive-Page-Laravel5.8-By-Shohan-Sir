<?php $__env->startSection('content'); ?>

<div class="col-lg-8 offset-2">
<h2>Contact Message view</h2>
<table class="table table-bordered mt-5">
            <thead>
               <tr>
                  <th>First Name</th>
                  <th>subject</th>
                  <th>Message</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $ContactMessage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr class=<?php echo e(($Contact->read_status==1)? "bg-info":""); ?>>
                  <td><?php echo e($Contact->first_name); ?></td>
                  <td><?php echo e($Contact->subject); ?></td>
                  <td><?php echo e($Contact->	message); ?></td>
                  <td>
                            <a href="<?php echo e(url('Message/Read/status')); ?>/<?php echo e($Contact->id); ?>"
                                class="btn btn-sm btn-info">Read</a>
                        </td>
               </tr>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </tbody>
         </table>
         <?php echo e($ContactMessage->links()); ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\josim\blog\resources\views/product/Contact/message.blade.php ENDPATH**/ ?>