<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ContactModel;
use Mail;
use App\Mail\contactmessage;
class ContactController extends Controller
{
function contactView(){
    return view('frontend.contact');
}

// Contact Data Insert

function contactinsert(Request $request){
    ContactModel::insert($request->except('_token'));
    
//   Send Mail To Company mail
    $first_name = $request->first_name;
    $message = $request->message;

 Mail::to('josimuddin228586@gmail.com')->send(new contactmessage($first_name, $message));

    return back()->with('status','Message Sent successfull!!');

}


// Contact Backend Control

function contactbackview(){
    $ContactMessage = ContactModel::orderBy('id','desc')->paginate(5);
    return view('product.Contact.message',compact('ContactMessage'));
}
function MessageReadstatus($message_id){
if(ContactModel::find($message_id)->read_status==1){
    ContactModel::find($message_id)->update([
        'read_status' => 2
    ]);
}
return back();

}


}
