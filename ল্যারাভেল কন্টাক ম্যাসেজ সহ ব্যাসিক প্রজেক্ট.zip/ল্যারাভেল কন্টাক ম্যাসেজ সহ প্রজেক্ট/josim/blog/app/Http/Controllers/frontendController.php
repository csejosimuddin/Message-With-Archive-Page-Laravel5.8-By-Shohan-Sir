<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\productModel;
use App\categories;
class frontendController extends Controller
{
    function index(){
        $all_product = productModel::all();
        $product = productModel::all();
        $categories = categories::all();
       return view('frontend.index', compact('all_product','product','categories'));
    }



        function productDetails($product_id){
            
            $single_product_info = productModel::findOrFail($product_id);
            $related_product = productModel::where('id', '!=',$product_id)->where('category_p_id',$single_product_info->category_p_id)->get();
            return view('frontend.productdetails', compact('single_product_info','related_product'));
            
        }


        function categorywiseproduct($category_id){
            $categoriproducts = productModel::where('category_p_id', $category_id)->get();
        return view('frontend.categoryWaiseproduct', compact('categoriproducts'));
        
         }


}