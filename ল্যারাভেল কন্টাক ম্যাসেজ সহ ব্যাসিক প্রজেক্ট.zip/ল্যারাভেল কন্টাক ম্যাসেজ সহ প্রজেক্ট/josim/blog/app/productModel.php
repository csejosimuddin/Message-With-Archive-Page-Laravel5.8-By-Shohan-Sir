<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class productModel extends Model
{
    use SoftDeletes;
    
    public $table='products';
    public $primaryKey='id';
    public $incrementing=true;
    public $keyType='int';
    public  $timestamps=true;

    protected $fillable = ['Product_Name','Product_Description','Product_Price','Product_Quentity','Product_Alert_Quentity','Product_image','category_p_id'];
    function relationtocategory(){
        return $this->hasOne('App\categories', 'id', 'category_p_id');
    }



}
