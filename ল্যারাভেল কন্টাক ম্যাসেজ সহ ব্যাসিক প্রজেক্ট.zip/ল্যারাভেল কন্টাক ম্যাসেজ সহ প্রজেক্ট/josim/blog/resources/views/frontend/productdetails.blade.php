
@extends('layouts.frontendapp')
@section('title','HomePAge')
@section('content')



<section id="section-padding">
<div class="container">
	<div class="row">
		<div class="col-lg-6">
			<img src="{{ asset('uploads/product_photos') }}/{{ $single_product_info->Product_image }}" width="100%" height="auto">
			
		</div>

		<div class="col-lg-6">
			<h2>{{$single_product_info->Product_Name}}</h2>
			<td>Categori Name:{{ $single_product_info->relationtocategory->category_id }}</td>
			<p>{{$single_product_info->Product_Description}}</p>
			<a href="#">Add To Cart</a>
		</div>
		
	</div>
	
</div>

</section>



<style type="text/css">
	#section-padding{
		padding: 80px 0px;
	}
</style>

<section id="section-padding">
	<div class="related text-center">	<h1>Related Product</h1></div>
	<div class="container">
		<div class="row">

        @foreach($related_product as $related_product)
			<div class="col-lg-4">
            <a href="{{ url('product/Details') }}/{{ $related_product->id }}" class="site-btn btn-line">
				<img src="{{ asset('uploads/product_photos') }}/{{ $related_product->Product_image }}" width="100%" height="auto">
                </a>
				<h5>{{ $related_product->Product_Name }}</h5>
                <span>{{ $related_product->Product_Price }}</span>
				<a href="#">Add To Cart</a>
			</div>
@endforeach

		 </div>
		
	</div>
</section>
@endsection