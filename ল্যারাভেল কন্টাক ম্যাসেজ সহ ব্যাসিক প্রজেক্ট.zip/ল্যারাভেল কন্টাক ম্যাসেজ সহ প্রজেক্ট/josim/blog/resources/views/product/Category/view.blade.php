@extends('layouts.app')
@section('content')



<div class="container">
    <div class="row">
        <div class="col-lg-4">
            <div class="card px-3 py-3">
                <div class="card-header bg-success">
                    Add Category Form
                </div>
                @if(session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
                @endif
                @if($errors->all())
                <div class="alert alert-danger">
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </div>
                @endif


                <form action="{{ url('/add/category/insert') }}" method="post">
                    @csrf
                    <div class="form-group">
                        <label>Category Name</label>
                        <input type="text" class="form-control" name="category_name" placeholder="Enter Category Name">
                    </div>

                    <div class="form-group">
                        <input type="checkbox" name="menu_status" value="1" id="menu">
                        <label for="menu">Use as Menu</label>
                    </div>

                    <button type="submit" class="btn btn-info">Add Category</button>
                </form>
            </div>
        </div>
        <div class="col-lg-8">

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>SL.NO</th>
                        <th>Category Name</th>
                        <th>Menu Status</th>
                        <th>Action</th>
                        <th>created_at</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
                    @forelse($categories as $category)
                    <tr>
                        <td>{{ $loop->index+1 }}</td>
                        <td>{{ $category->category_id }}</td>
                        <td>{{ ($category->menu_status==1)? "Yes":"No" }}</td>


                        <td>{{ $category->created_at->format('d-m-y') }}</td>
                        <td>
                            <a href="{{ url('change/menu/status') }}/{{ $category->id }}"
                                class="btn btn-sm btn-info">Change Menu</a>
                        </td>




                    </tr>
                    @empty

                    <tr class="text-center">
                        <td colspan="6"> No Data Available</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>

        </div>
    </div>
</div>





@endsection