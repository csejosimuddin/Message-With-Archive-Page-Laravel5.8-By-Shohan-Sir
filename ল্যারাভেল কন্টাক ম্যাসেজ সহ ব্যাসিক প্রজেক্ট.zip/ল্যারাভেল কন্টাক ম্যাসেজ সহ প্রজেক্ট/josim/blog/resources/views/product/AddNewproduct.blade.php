@extends('layouts.app')
@section('content')

<div class="container">
<div class="row">
<div class="col-lg-4">
<div class="card px-3 py-3">
<form action="{{ url('/add/product/insert') }}" method="post" enctype="multipart/form-data">
               @csrf

               <div class="form-group">
                  <label>Select Category</label>
                  <select class="form-control" name="categoryselectid">
                  <option class="d-none" value="">--Select--</option>
               @foreach($categories as $category)
                  <option value="{{ $category->id }}">{{ $category->category_id }}</option>
                     @endforeach
                  </select>
               </div>

               <div class="form-group">
                  <label>Product Name</label>
                  <input type="text" class="form-control" name="Product_Name_josim" placeholder="Enter Product Name" value="{{ old('Product_Name_josim') }}">
               </div>
               <div class="form-group">
                  <label>Product Description</label>
                  <textarea class="form-control" name="Product_Description" rows="3" placeholder="Enter Product Description">{{ old('Product_Description') }}</textarea>
               </div>
               <div class="form-group">
                  <label>Product Price</label>
                  <input type="text" class="form-control" name="Product_Price" placeholder="Enter Product Price" value="{{ old('Product_Price') }}">
               </div>
               <div class="form-group">
                  <label>Product Quentity</label>
                  <input type="text" class="form-control" name="Product_Quentity" placeholder="Enter Product Quentity" value="{{ old('Product_Quentity') }}">
               </div>
               <div class="form-group">
                  <label>Product Alert Quentity</label>
                  <input type="text" class="form-control" name="Product_Alert_Quentity" placeholder="Enter Product Alert Quentity" value="{{ old('Product_Alert_Quentity') }}">
               </div>               
               <div class="form-group">
                  <label>Product Image</label>
                  <input type="file" class="form-control" name="Product_image">
               </div>

               <button type="submit" class="btn btn-info">Submit</button>
            </form>



</div>
</div>


<div class="col-lg-8">
         <!-- এর মাধমে success alert টা পাবো -->
         @if(session('deletestatus')) 
         <!-- status এটা addproductinsert Conroller থেকে আসছে -->
         <div class="alert alert-danger">
            {{ session('deletestatus') }}
         </div>
         @endif
         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>SL.NO</th>
                  <th>Category Name</th>
                  <th>Product_Name</th>
                  <th>Product_Description</th>
                  <th>Product_Price</th>
                  <th>Product_Quentity</th>
                  <th>Alert_Quentity</th>
                  <th>Product Image</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>
               @forelse( $all_Products as $all_Product )
               <tr>
                  <td>{{ $loop->index+1 }}</td>
                
                <td>{{ $all_Product->relationtocategory->category_id }}</td>
                  <td>{{ $all_Product->Product_Name }}</td>
                  <td>{{ Str::limit($all_Product->Product_Description, 20) }}</td>
                  <td>{{ $all_Product->Product_Price }}</td>
                  <td>{{ $all_Product->Product_Quentity }}</td>
                  <td>{{ $all_Product->Product_Alert_Quentity }}</td>
                  
               

                  <td>
                  	<img src="{{ asset('uploads/product_photos') }}/{{ $all_Product->Product_image }}" alt="No Images Found" width="60">
                  </td>

                  <td>
                     <a href="{{ url('/delete/product') }}/{{ $all_Product->id }}" class="btn btn-sm btn-danger">
                     Delete</a><br>
                     <hr>

                     <a href="{{ url('/edit/product') }}/{{ $all_Product->id }}" class="btn btn-sm btn-info">
                     Edit</a>
                  </td>
               </tr>
               @empty
               <tr class="text-center">
                  <td colspan="6"> No Data Available</td>
               </tr>
               @endforelse
            </tbody>
         </table>
         {{ $all_Products->links() }}
         


         <h2 class="text-center">SHow SoftDelete Product</h2>
         <table class="table table-bordered mt-5">
            <thead>
               <tr>
                  <th>SL.NO</th>
                  <th>Product_Name</th>
                  <th>Product_Description</th>
                  <th>Product_Price</th>
                  <th>Product_Quentity</th>
                  <th>Alert_Quentity</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>
               <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
               @forelse( $deteted_product_show as $deteted_product_show )
               <tr>
                  <td>{{ $loop->index+1 }}</td>
                  <td>{{ $deteted_product_show->Product_Name }}</td>
                  <td>{{ Str::limit($deteted_product_show->Product_Description, 20) }}</td>
                  <td>{{ $deteted_product_show->Product_Price }}</td>
                  <td>{{ $deteted_product_show->Product_Quentity }}</td>
                  <td>{{ $deteted_product_show->Product_Alert_Quentity }}</td>
                  <td>
                     <a href="{{ url('/restore/product') }}/{{ $deteted_product_show->id }}" class="btn btn-sm btn-danger">
                     Restore</a><br>
                     <hr>
                     <a href="{{ url('/permantlyDelete/product') }}/{{ $deteted_product_show->id }}" class="btn btn-sm btn-info">
                     Delete Parmently</a>
                  </td>
               </tr>
               @empty
               <tr class="text-center">
                  <td colspan="6"> No Data Available</td>
               </tr>
               @endforelse
            </tbody>
         </table>



      </div>



</div>

</div>

@endsection