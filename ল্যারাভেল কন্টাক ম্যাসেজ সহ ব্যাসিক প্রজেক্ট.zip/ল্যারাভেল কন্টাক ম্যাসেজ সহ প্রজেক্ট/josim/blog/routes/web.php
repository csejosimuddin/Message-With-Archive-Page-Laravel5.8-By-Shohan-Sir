<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// Backend Product or CRUD Operation Route
Route::get('/Add/Product/View','ProductCongtroller@index');
Route::post('/add/product/insert','ProductCongtroller@addproductinsert');
Route::get('/edit/product/{product_id}','ProductCongtroller@editproduct');
Route::post('/edit/product/insert','ProductCongtroller@editproductinsert');
Route::get('/delete/product/{product_id}','ProductCongtroller@deleteproduct');
Route::get('/restore/product/{product_id}','ProductCongtroller@restore_product');
Route::get('/permantlyDelete/product/{product_id}','ProductCongtroller@permantlyDeleteProduct');

// Category
Route::get('/Add/Category/View','CategoryCongtroller@view');
Route::post('/add/category/insert','CategoryCongtroller@addcategoryinsert');
Route::get('category/wise/product/{category_id}','frontendController@categorywiseproduct');
Route::get('change/menu/status/{category_id}','CategoryCongtroller@changemenustatus');

// Frontend Operation
Route::get('/', 'frontendController@index');
Route::get('product/Details/{product_id}', 'frontendController@productDetails');

// Contact Page
Route::get('contact/view', 'ContactController@contactView');
Route::post('contact/insert','ContactController@contactinsert');
// Backend Contact Route View
Route::get('Message/Back/View', 'ContactController@contactbackview');
Route::get('Message/Read/status/{message_id}','ContactController@MessageReadstatus');